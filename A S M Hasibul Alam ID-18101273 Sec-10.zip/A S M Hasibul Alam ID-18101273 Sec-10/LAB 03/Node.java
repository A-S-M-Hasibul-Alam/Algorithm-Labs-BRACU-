package lab03;

//package Lab3;

import java.util.ArrayList;

public class Node {
	int distance;
	int vigitedOrExplored;
	ArrayList path;
	
	Node(){
		path = new ArrayList<Integer>();
	}
	
}
