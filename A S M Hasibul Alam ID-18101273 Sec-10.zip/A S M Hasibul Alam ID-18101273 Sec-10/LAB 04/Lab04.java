/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab04;

/**
 *
 * @author 18101182
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Lab04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
       
           File file = new File("C:\\Users\\USER\\Desktop\\Lab codes\\Lab04\\src\\lab04\\input.txt");
          
           Scanner sc = new Scanner(file);
           int sz = sc.nextInt();
           int adj [][] = new int[sz] [sz];
           while(sc.hasNextInt()){
          adj[sc.nextInt()] [sc.nextInt()]=1;
           }
    
        DFS a = new DFS(sz,adj);
        a.dfs(1);
        int x=1;
        while(x<a.V){
            if(!a.clr[x].equals("BLACK")){
            a.dfs(x);
            }
            x++;
        }
       // a.processed();
        a.visited();
        a.processed();
        
        a.DAG();
}
}
